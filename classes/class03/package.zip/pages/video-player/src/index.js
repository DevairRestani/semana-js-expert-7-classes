import factory from "./factory.js"

await factory.initalize()